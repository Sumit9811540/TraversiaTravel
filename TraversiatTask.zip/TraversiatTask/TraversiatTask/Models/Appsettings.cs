﻿namespace TraversiatTask.Models
{
    //public class Appsettings
    //{
    //}
    //// Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class ConnectionStrings
    {
        public string UserDB { get; set; }
    }

    public class Appsettings
    {
        public ConnectionStrings ConnectionStrings { get; set; }
        
    }


}
