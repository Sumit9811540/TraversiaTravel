﻿using System.ComponentModel.DataAnnotations;

namespace TraversiatTask.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Name must not contain spaces or special characters.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [RegularExpression(@"^[^@\s]+@[^@\s]+\.[^@\s]+$", ErrorMessage = "Invalid email format.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Mobile is required.")]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Mobile must be 10 digits.")]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "Gender is required.")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Address is required.")]
        [RegularExpression(@"^\S+$", ErrorMessage = "Address must not contain spaces.")]
        public string Address { get; set; }

       //[Required(ErrorMessage = "Image is required.")]
       // public byte[] ProfileImage { get; set; }

    }
}


