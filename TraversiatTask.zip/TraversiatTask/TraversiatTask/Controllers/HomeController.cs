using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Options;
using System.Data.SqlClient;
using System.Diagnostics;
using TraversiatTask.DBActivity;
using TraversiatTask.Models;

namespace TraversiatTask.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly Appsettings _appsettings;

        public HomeController(ILogger<HomeController> logger, IOptions<Appsettings> appsetting)
        {
            _logger = logger;
            _appsettings = appsetting.Value;
        }

        public ActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Index(Login model)
        {
            if (ModelState.IsValid)
            {
                model.UserName = "sumit";
                model.Password = "admin";
                if (model.UserName == "sumit" && model.Password == "admin")
                {

                    return RedirectToAction("Create");
                }
                else
                {

                    ViewBag.Error = "Invalid username or password";
                }
            }
            return View(model);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(User user)
        {

            bool insertdata = false;
            if (ModelState.IsValid)
            {
                if (user != null)
                {
                    insertdata = new UserRepository().InsrtData(user);
                    if (insertdata == true)
                    {
                        return RedirectToAction("List");
                    }
                    else
                    {
                        ViewBag.Error = "Duplicate value found - Email or Mobile already exists";
                    }

                }
            }

            return View(user);

        }
        public ActionResult List()
        {

            var users = new UserRepository().GetAllUsers();

            return View(users);
        }
     
        public IActionResult Edit(int id)
        {
            if (id <= 0)
                return RedirectToAction("List");
            var user = new UserRepository().GetUserById(id);

            if (user == null)
                return NotFound();

            return View(user);
        }
        [HttpPost]
        public IActionResult Edit(User user)
        {
            if (!ModelState.IsValid)
            {
                return View(user);
            }

            bool updated = new UserRepository().UpdateUser(user);

            if (updated)
                return RedirectToAction("List");

            ViewBag.Error = "Something went wrong while updating.";
            return View(user);
        }

        public ActionResult Delete(int id)
        {
            bool deleted = new UserRepository().DeleteUser(id);

            if (!deleted)
            {
                ViewBag.Error = "Something went wrong. User not deleted.";
            }
            else
            {
                ViewBag.Error = "User deleted successfully.";
            }

            return RedirectToAction("List");
        }





        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
