﻿using Microsoft.CodeAnalysis.Elfie.Diagnostics;
using Microsoft.Extensions.Options;
using System.Data.SqlClient;
using TraversiatTask.Controllers;
using TraversiatTask.Models;

namespace TraversiatTask.DBActivity
{
    public  class UserRepository
    {

        string connStr = "Data Source=DESKTOP-0LSS3AS\\SQLEXPRESS01;Initial Catalog=EmployeeDB;Integrated Security=True";
        public bool InsrtData(User user)
        {
            bool isInserted = false;
            string fileName = null;

            try
            {
                //if (ProfileImageFile != null && ProfileImageFile.Length > 0)
                //{
                //    using (var ms = new MemoryStream())
                //    {
                //        ProfileImageFile.CopyTo(ms);
                //        user.ProfileImage = ms.ToArray();
                //    }
                //}


                using (SqlConnection con = new SqlConnection(connStr))
                {
                    con.Open();

                    // Step 1: Check if Email or Mobile already exists
                    string checkduplicate = @"SELECT COUNT(*) FROM Users WHERE Email = @Email OR Mobile = @Mobile";

                    using (SqlCommand checkCmd = new SqlCommand(checkduplicate, con))
                    {
                        checkCmd.Parameters.AddWithValue("@Email", user.Email ?? (object)DBNull.Value);
                        checkCmd.Parameters.AddWithValue("@Mobile", user.Mobile ?? (object)DBNull.Value);

                        int count = (int)checkCmd.ExecuteScalar();

                        if (count > 0)
                        {
                           
                            isInserted = false;
                        }
                        else
                        {

                            string insertvalues = @"INSERT INTO Users (Name, Email, Mobile, Gender, Address) 
                                   VALUES (@Name, @Email, @Mobile, @Gender, @Address)";


                            using (SqlCommand cmd = new SqlCommand(insertvalues, con))
                            {
                                cmd.Parameters.AddWithValue("@Name", user.Name ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@Email", user.Email ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@Mobile", user.Mobile ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@Gender", user.Gender ?? (object)DBNull.Value);
                                cmd.Parameters.AddWithValue("@Address", user.Address ?? (object)DBNull.Value);
                               
                                int rowsAffected = cmd.ExecuteNonQuery();
                                isInserted = rowsAffected > 0;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw new Exception("Error inserting data", ex);
            }

            return isInserted;
        }

   

        public List<User> GetAllUsers()
        {
            List<User> userList = new List<User>();

            using (SqlConnection con = new SqlConnection(connStr))
            {
                string query = "SELECT Id, Name, Email, Mobile, Gender, Address FROM Users";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    userList.Add(new User
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Name = reader["Name"].ToString(),
                        Email = reader["Email"].ToString(),
                        Mobile = reader["Mobile"].ToString(),
                        Gender = reader["Gender"].ToString(),
                        Address = reader["Address"].ToString()
                        //ProfileImage = reader["ProfileImage"].ToString()
                    });
                }
            }

            return userList;
        }

        public User GetUserById(int id)
        {
            User user = null;

            using (SqlConnection con = new SqlConnection(connStr))
            {
                string query = "SELECT Id, Name, Email, Mobile, Gender, Address FROM Users WHERE Id = @Id";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Id", id);

                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            user = new User
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Name = reader["Name"].ToString(),
                                Email = reader["Email"].ToString(),
                                Mobile = reader["Mobile"].ToString(),
                                Gender = reader["Gender"].ToString(),
                                Address = reader["Address"].ToString(),
                               // ProfileImagePath = reader["ProfileImage"].ToString() // Assuming you store relative path
                            };
                        }
                    }
                }
            }

            return user;
        }

        public bool DeleteUser(int id)
        {
            int rowsAffected = 0;

            using (SqlConnection con = new SqlConnection(connStr))
            {
                string query = "DELETE FROM Users WHERE Id = @Id";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Id", id);

                    con.Open();
                    rowsAffected = cmd.ExecuteNonQuery();
                }
            }

            return rowsAffected > 0; 
        }

        public bool UpdateUser(User user)
        {
            int rowsAffected = 0;

            using (SqlConnection con = new SqlConnection(connStr))
            {
                string query = @"UPDATE Users 
                         SET Name=@Name, Email=@Email, Mobile=@Mobile, Gender=@Gender, 
                             Address=@Address
                         WHERE Id=@Id";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Id", user.Id);
                    cmd.Parameters.AddWithValue("@Name", user.Name);
                    cmd.Parameters.AddWithValue("@Email", user.Email);
                    cmd.Parameters.AddWithValue("@Mobile", user.Mobile);
                    cmd.Parameters.AddWithValue("@Gender", user.Gender);
                    cmd.Parameters.AddWithValue("@Address", user.Address);
                    //cmd.Parameters.AddWithValue("@ProfileImage", user.ProfileImagePath ?? string.Empty);

                    con.Open();
                    rowsAffected = cmd.ExecuteNonQuery();
                }
            }

            return rowsAffected > 0;
        }

    }

}
